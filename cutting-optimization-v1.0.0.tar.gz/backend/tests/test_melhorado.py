#!/usr/bin/env python3
"""
Teste comparando o algoritmo melhorado com o anterior
"""

from cutting_optimizer_fast import FastCuttingOptimizer
from cutting_optimizer_improved import ImprovedCuttingOptimizer
from visualization import CuttingVisualizer
import time


def test_comparacao_algoritmos():
    """Compara os dois algoritmos"""
    print("🔬 COMPARAÇÃO DE ALGORITMOS")
    print("=" * 40)
    
    # Configurar problema
    stock_width = 800
    stock_height = 600
    pieces = [
        (200, 150, 3),  # 3 peças grandes
        (100, 100, 5),  # 5 peças médias
        (50, 50, 8),    # 8 peças pequenas
    ]
    
    print(f"📏 Material: {stock_width}x{stock_height} mm")
    print(f"🧩 Peças: {pieces}")
    
    results = []
    
    # Teste 1: Algoritmo rápido
    print(f"\n🔧 TESTANDO ALGORITMO RÁPIDO...")
    optimizer1 = FastCuttingOptimizer(
        stock_width=stock_width,
        stock_height=stock_height,
        pieces=pieces,
        allow_rotation=True
    )
    
    start_time = time.time()
    result1 = optimizer1.optimize(time_limit=30)
    total_time1 = time.time() - start_time
    
    efficiency1 = (result1.used_area / result1.total_area) * 100
    print(f"  Peças cortadas: {len(result1.pieces_placed)}")
    print(f"  Área utilizada: {result1.used_area:,} mm²")
    print(f"  Desperdício: {result1.waste_percentage:.2f}%")
    print(f"  Eficiência: {efficiency1:.1f}%")
    print(f"  Tempo: {total_time1:.3f}s")
    
    results.append({
        'name': 'Algoritmo Rápido',
        'result': result1,
        'stock_width': stock_width,
        'stock_height': stock_height,
        'pieces_placed': result1.pieces_placed,
        'waste_percentage': result1.waste_percentage
    })
    
    # Teste 2: Algoritmo melhorado
    print(f"\n🔧 TESTANDO ALGORITMO MELHORADO...")
    optimizer2 = ImprovedCuttingOptimizer(
        stock_width=stock_width,
        stock_height=stock_height,
        pieces=pieces,
        allow_rotation=True
    )
    
    start_time = time.time()
    result2 = optimizer2.optimize(time_limit=30)
    total_time2 = time.time() - start_time
    
    efficiency2 = (result2.used_area / result2.total_area) * 100
    print(f"  Peças cortadas: {len(result2.pieces_placed)}")
    print(f"  Área utilizada: {result2.used_area:,} mm²")
    print(f"  Desperdício: {result2.waste_percentage:.2f}%")
    print(f"  Eficiência: {efficiency2:.1f}%")
    print(f"  Tempo: {total_time2:.3f}s")
    
    results.append({
        'name': 'Algoritmo Melhorado',
        'result': result2,
        'stock_width': stock_width,
        'stock_height': stock_height,
        'pieces_placed': result2.pieces_placed,
        'waste_percentage': result2.waste_percentage
    })
    
    # Comparação
    print(f"\n📊 COMPARAÇÃO:")
    print(f"  Melhoria em peças: {len(result2.pieces_placed) - len(result1.pieces_placed)} peças")
    print(f"  Melhoria em área: {result2.used_area - result1.used_area:,} mm²")
    print(f"  Melhoria em eficiência: {efficiency2 - efficiency1:.1f}%")
    print(f"  Diferença de tempo: {total_time2 - total_time1:.3f}s")
    
    # Visualizar comparação
    print(f"\n📊 GERANDO VISUALIZAÇÃO...")
    from visualization import create_comparison_visualization
    create_comparison_visualization(
        results,
        [r['name'] for r in results]
    )
    
    return results


def test_problema_maior():
    """Teste com problema maior para ver a diferença"""
    print(f"\n🚀 TESTE COM PROBLEMA MAIOR")
    print("=" * 35)
    
    stock_width = 1000
    stock_height = 800
    pieces = [
        (150, 100, 8),   # 8 peças médias
        (100, 100, 12),  # 12 quadrados
        (75, 75, 15),    # 15 quadrados pequenos
        (50, 50, 20),    # 20 quadrados muito pequenos
    ]
    
    print(f"📏 Material: {stock_width}x{stock_height} mm")
    print(f"🧩 Total de peças: {sum(q for _, _, q in pieces)}")
    
    # Teste algoritmo melhorado
    optimizer = ImprovedCuttingOptimizer(
        stock_width=stock_width,
        stock_height=stock_height,
        pieces=pieces,
        allow_rotation=True
    )
    
    print(f"\n🔧 Otimizando...")
    start_time = time.time()
    result = optimizer.optimize(time_limit=60)
    total_time = time.time() - start_time
    
    efficiency = (result.used_area / result.total_area) * 100
    print(f"\n✅ RESULTADOS:")
    print(f"  Peças cortadas: {len(result.pieces_placed)}")
    print(f"  Área utilizada: {result.used_area:,} mm²")
    print(f"  Desperdício: {result.waste_percentage:.2f}%")
    print(f"  Eficiência: {efficiency:.1f}%")
    print(f"  Tempo: {total_time:.3f}s")
    
    # Mostrar detalhes das peças
    print(f"\n🧩 DETALHES DAS PEÇAS:")
    piece_groups = {}
    for piece in result.pieces_placed:
        base_id = piece['id'].split('_rot')[0]
        if base_id not in piece_groups:
            piece_groups[base_id] = []
        piece_groups[base_id].append(piece)
    
    for base_id, pieces_list in piece_groups.items():
        print(f"  {base_id}: {len(pieces_list)} peças")
    
    # Visualizar resultado
    print(f"\n📊 GERANDO VISUALIZAÇÃO...")
    visualizer = CuttingVisualizer(stock_width, stock_height)
    visualizer.visualize_cutting_plan(
        result.pieces_placed,
        title="Problema Maior - Algoritmo Melhorado"
    )
    
    return result


if __name__ == "__main__":
    try:
        print("🧪 TESTE DO ALGORITMO MELHORADO")
        print("=" * 50)
        
        # Comparação de algoritmos
        results = test_comparacao_algoritmos()
        
        # Teste com problema maior
        result_maior = test_problema_maior()
        
        print(f"\n🎉 TESTES CONCLUÍDOS!")
        print(f"✅ Algoritmo melhorado testado")
        print(f"✅ Comparações realizadas")
        print(f"✅ Visualizações geradas")
        
    except Exception as e:
        print(f"\n❌ Erro durante os testes: {e}")
        import traceback
        traceback.print_exc()
