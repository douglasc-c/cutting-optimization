#!/usr/bin/env python3
"""
Teste muito rápido do algoritmo de otimização de corte
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from src.core import SimpleCuttingOptimizer
import time


def test_muito_simples():
    """Teste com problema muito simples"""
    print("🚀 TESTE MUITO SIMPLES")
    print("=" * 30)
    
    # Problema muito simples
    stock_width = 400
    stock_height = 300
    pieces = [
        (100, 100, 3),  # 3 quadrados pequenos
        (150, 100, 2),  # 2 retângulos
    ]
    
    print(f"Material: {stock_width}x{stock_height} mm")
    print(f"Peças: {pieces}")
    
    # Criar otimizador
    optimizer = SimpleCuttingOptimizer(
        stock_width=stock_width,
        stock_height=stock_height,
        pieces=pieces,
        allow_rotation=True
    )
    
    # Executar otimização
    print("\n🔧 Otimizando...")
    start_time = time.time()
    result = optimizer.optimize(time_limit=10)  # Limite de 10 segundos
    total_time = time.time() - start_time
    
    # Mostrar resultados
    print(f"\n✅ RESULTADOS:")
    print(f"Peças cortadas: {len(result.pieces_placed)}")
    print(f"Área utilizada: {result.used_area:,} mm²")
    print(f"Desperdício: {result.waste_percentage:.2f}%")
    print(f"Tempo: {total_time:.3f} segundos")
    
    # Mostrar peças
    print(f"\n🧩 PEÇAS COLOCADAS:")
    for i, piece in enumerate(result.pieces_placed, 1):
        print(f"  {i}. {piece['id']}: ({piece['x']}, {piece['y']}) - {piece['width']}x{piece['height']}mm")
    
    return result


def test_sem_rotacao():
    """Teste sem rotação para ser ainda mais rápido"""
    print("\n🔄 TESTE SEM ROTAÇÃO")
    print("=" * 25)
    
    stock_width = 300
    stock_height = 200
    pieces = [
        (100, 100, 2),  # 2 quadrados
        (150, 50, 2),   # 2 retângulos
    ]
    
    print(f"Material: {stock_width}x{stock_height} mm")
    print(f"Peças: {pieces}")
    
    optimizer = SimpleCuttingOptimizer(
        stock_width=stock_width,
        stock_height=stock_height,
        pieces=pieces,
        allow_rotation=False  # Sem rotação = mais rápido
    )
    
    print("\n🔧 Otimizando...")
    start_time = time.time()
    result = optimizer.optimize(time_limit=5)  # Apenas 5 segundos
    total_time = time.time() - start_time
    
    print(f"\n✅ RESULTADOS:")
    print(f"Peças cortadas: {len(result.pieces_placed)}")
    print(f"Desperdício: {result.waste_percentage:.2f}%")
    print(f"Tempo: {total_time:.3f} segundos")
    
    return result


if __name__ == "__main__":
    try:
        print("🧪 TESTE RÁPIDO DO ALGORITMO")
        print("=" * 40)
        
        # Teste 1: Muito simples
        result1 = test_muito_simples()
        
        # Teste 2: Sem rotação
        result2 = test_sem_rotacao()
        
        print(f"\n🎉 TESTES CONCLUÍDOS!")
        print(f"✅ Algoritmo funcionando corretamente")
        print(f"✅ Tempo total: {result1.execution_time + result2.execution_time:.3f} segundos")
        
    except Exception as e:
        print(f"\n❌ Erro: {e}")
        import traceback
        traceback.print_exc()
