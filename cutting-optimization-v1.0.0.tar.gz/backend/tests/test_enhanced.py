#!/usr/bin/env python3
"""
Teste do algoritmo de otimização melhorado
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.core.cutting_optimizer_enhanced import EnhancedCuttingOptimizer

def test_enhanced_algorithm():
    """Testa o algoritmo melhorado com as peças do usuário"""
    
    # Configuração baseada nas peças do usuário
    stock_width = 1000
    stock_height = 800
    
    # Peças do usuário (baseado na imagem)
    pieces = [
        (200, 300, 2),  # Peça 1: 200 x 300 mm, 2 unidades
        (150, 200, 3),  # Peça 2: 150 x 200 mm, 3 unidades
        (200, 100, 1),  # Peça 3: 200 x 100 mm, 1 unidade
        (100, 300, 3),  # Peça 4: 100 x 300 mm, 3 unidades
        (150, 400, 1),  # Peça 5: 150 x 400 mm, 1 unidade
        (150, 90, 4),   # Peça 6: 150 x 90 mm, 4 unidades
    ]
    
    print("🧪 Testando Algoritmo Melhorado")
    print("=" * 50)
    print(f"Material: {stock_width} x {stock_height} mm")
    print(f"Área total: {stock_width * stock_height:,} mm²")
    print(f"Peças a cortar: {len(pieces)} tipos")
    
    total_pieces = sum(quantity for _, _, quantity in pieces)
    print(f"Total de peças: {total_pieces}")
    
    # Calcular área total das peças
    total_piece_area = sum(width * height * quantity for width, height, quantity in pieces)
    print(f"Área total das peças: {total_piece_area:,} mm²")
    
    # Criar otimizador
    optimizer = EnhancedCuttingOptimizer(
        stock_width=stock_width,
        stock_height=stock_height,
        pieces=pieces,
        allow_rotation=True
    )
    
    # Executar otimização
    print("\n🔧 Executando otimização...")
    result = optimizer.optimize(time_limit=30)
    
    # Mostrar resultados
    print("\n✅ RESULTADOS")
    print(f"Peças colocadas: {len(result.pieces_placed)}")
    print(f"Área utilizada: {result.used_area:,} mm²")
    print(f"Desperdício: {result.waste_percentage:.2f}%")
    print(f"Eficiência de área: {(result.used_area / result.total_area) * 100:.1f}%")
    print(f"Tempo de execução: {result.execution_time:.2f} segundos")
    
    # Mostrar peças colocadas
    print("\n📋 PEÇAS COLOCADAS:")
    for i, piece in enumerate(result.pieces_placed, 1):
        print(f"  {i}. {piece['id']}: ({piece['x']}, {piece['y']}) - {piece['width']} x {piece['height']} mm")
    
    # Estatísticas
    stats = optimizer.get_statistics()
    print(f"\n📊 ESTATÍSTICAS:")
    print(f"  Algoritmo: {stats['algorithm']}")
    print(f"  Rotação permitida: {stats['allow_rotation']}")
    print(f"  Desperdício teórico: {stats['theoretical_waste']:.2f}%")
    
    return result

if __name__ == "__main__":
    test_enhanced_algorithm()
