#!/usr/bin/env python3
"""
Teste rápido do algoritmo de otimização de corte simplificado
"""

from cutting_optimizer_simple import SimpleCuttingOptimizer
from visualization import CuttingVisualizer
import time


def test_simple_cutting():
    """Teste simples de otimização"""
    print("🧪 TESTE DO ALGORITMO SIMPLIFICADO")
    print("=" * 50)
    
    # Configurar problema simples
    stock_width = 1000
    stock_height = 800
    pieces = [
        (200, 300, 2),  # 2 peças de 200x300mm
        (150, 200, 3),  # 3 peças de 150x200mm
        (100, 100, 5)   # 5 peças de 100x100mm
    ]
    
    print(f"Material base: {stock_width}x{stock_height} mm")
    print(f"Peças: {pieces}")
    
    # Criar otimizador
    optimizer = SimpleCuttingOptimizer(
        stock_width=stock_width,
        stock_height=stock_height,
        pieces=pieces,
        allow_rotation=True
    )
    
    # Mostrar estatísticas
    stats = optimizer.get_statistics()
    print(f"\n📊 ESTATÍSTICAS:")
    print(f"Área total: {stats['stock_area']:,} mm²")
    print(f"Total de peças: {stats['total_pieces']}")
    print(f"Área das peças: {stats['total_piece_area']:,} mm²")
    print(f"Desperdício teórico: {stats['theoretical_waste']:.1f}%")
    
    # Executar otimização
    print(f"\n🔧 EXECUTANDO OTIMIZAÇÃO...")
    start_time = time.time()
    result = optimizer.optimize(time_limit=30)
    total_time = time.time() - start_time
    
    # Mostrar resultados
    print(f"\n✅ RESULTADOS:")
    print(f"Peças cortadas: {len(result.pieces_placed)}")
    print(f"Área utilizada: {result.used_area:,} mm²")
    print(f"Desperdício: {result.waste_percentage:.2f}%")
    print(f"Tempo de execução: {result.execution_time:.3f} segundos")
    print(f"Tempo total: {total_time:.3f} segundos")
    print(f"Solução ótima: {'Sim' if result.is_optimal else 'Não'}")
    
    # Mostrar peças colocadas
    print(f"\n🧩 PEÇAS COLOCADAS:")
    for i, piece in enumerate(result.pieces_placed, 1):
        print(f"  {i}. {piece['id']}: ({piece['x']}, {piece['y']}) - {piece['width']}x{piece['height']}mm")
    
    # Visualizar resultado
    print(f"\n📊 GERANDO VISUALIZAÇÃO...")
    visualizer = CuttingVisualizer(stock_width, stock_height)
    visualizer.visualize_cutting_plan(
        result.pieces_placed,
        title="Teste Simples - Algoritmo Heurístico"
    )
    
    return result


def test_comparison():
    """Teste comparando com e sem rotação"""
    print("\n🔄 TESTE DE COMPARAÇÃO")
    print("=" * 30)
    
    stock_width = 1200
    stock_height = 800
    pieces = [(300, 200, 3), (150, 100, 8), (200, 150, 4)]
    
    results = []
    
    for allow_rotation in [True, False]:
        print(f"\nTestando {'com' if allow_rotation else 'sem'} rotação...")
        
        optimizer = SimpleCuttingOptimizer(
            stock_width=stock_width,
            stock_height=stock_height,
            pieces=pieces,
            allow_rotation=allow_rotation
        )
        
        result = optimizer.optimize(time_limit=30)
        results.append({
            'name': f"{'Com' if allow_rotation else 'Sem'} Rotação",
            'result': result,
            'stock_width': stock_width,
            'stock_height': stock_height,
            'pieces_placed': result.pieces_placed,
            'waste_percentage': result.waste_percentage
        })
        
        print(f"  Desperdício: {result.waste_percentage:.2f}%")
        print(f"  Peças cortadas: {len(result.pieces_placed)}")
        print(f"  Tempo: {result.execution_time:.3f}s")
    
    # Visualizar comparação
    from visualization import create_comparison_visualization
    create_comparison_visualization(
        results,
        [r['name'] for r in results]
    )
    
    return results


if __name__ == "__main__":
    try:
        test_simple_cutting()
        test_comparison()
        print("\n🎉 Todos os testes executados com sucesso!")
        
    except Exception as e:
        print(f"\n❌ Erro durante os testes: {e}")
        import traceback
        traceback.print_exc()
