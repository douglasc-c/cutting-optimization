#!/usr/bin/env python3
"""
Script de teste simples para a API
"""

import sys
import os
import json

# Adicionar o diretório src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.api import api

def test_api():
    """Teste simples da API"""
    print("🧪 TESTE DA API")
    print("=" * 30)
    
    # Configuração de teste
    config = {
        'stock_width': 600,
        'stock_height': 400,
        'pieces': [
            (100, 100, 3),
            (150, 50, 2)
        ],
        'allow_rotation': True,
        'time_limit': 10
    }
    
    print(f"Configuração: {config}")
    
    # Testar otimização
    try:
        result = api.optimize_cutting(
            stock_width=config['stock_width'],
            stock_height=config['stock_height'],
            pieces=config['pieces'],
            algorithm='fast',
            allow_rotation=config['allow_rotation'],
            time_limit=config['time_limit']
        )
        
        if result['success']:
            print("✅ API funcionando corretamente!")
            print(f"Algoritmo: {result['algorithm']}")
            print(f"Peças cortadas: {len(result['result']['pieces_placed'])}")
            print(f"Desperdício: {result['result']['waste_percentage']:.2f}%")
            return result
        else:
            print(f"❌ Erro na API: {result['error']}")
            return None
            
    except Exception as e:
        print(f"❌ Erro ao testar API: {e}")
        return None

if __name__ == "__main__":
    test_api()
